<?php
/**
 * Project: travelhub.
 * User:    Iroegbu
 * Date:    2/5/2016
 * Time:    5:06 AM
 */

header("Location: ../index.php");
exit;