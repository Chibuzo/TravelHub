<?php

class Oya {
	protected function __construct() {
		
	}
}

?>