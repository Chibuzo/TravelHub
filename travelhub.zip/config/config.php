<?php
define("DB_NAME", "travelhub");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "");
